import {Component, OnInit} from '@angular/core';
import { AdminService} from "../../services/admin.service";
import {ActivatedRoute, Router} from "@angular/router";
import {FormBuilder, FormGroup, Validators} from "@angular/forms";
import {NzMessageService} from "ng-zorro-antd/message";

@Component({
  selector: 'app-update-car',
  templateUrl: './update-car.component.html',
  styleUrl: './update-car.component.scss'
})
export class UpdateCarComponent implements OnInit{

  isSpinning = false;
  carId:number=this.activatedRoute.snapshot.params["id"];
  imgChanged: boolean = false;
  selectedFile:any;
  imagePreview: string | ArrayBuffer | null = null;
  existingImage: string | null = null;
  updateForm!:FormGroup;

  listOfOption: Array<{ label: string, value: string }> = [];

  listOfBrands = ["ACURA", "AUDI", "BENTLEY",  "BMW",  "BUGATTI",  "BUICK",  "CADILLAC",  "CHERY",  "CHRYSLER",  "CITROEN",  "DODGE",  "FERRARI",  "FORD",  "GMC",  "HONDA",  "HYUNDAI",  "INFINITI",  "JAGUAR",  "JEEP",  "KIA",  "LAMBORGHINI",  "LAND ROVER",  "LEXUS",  "LINCOLN",  "LOTUS",  "MAHINDRA",  "MASERATI",  "MAZDA",  "McLAREN",  "MERCEDES-BENZ",  "MINI",  "MITSUBISHI",  "NISSAN",  "PAGANI",  "PORSCHE",  "RENAULT",  "ROLLS-ROYCE",  "ROVER",  "SUBARU",  "SUZUKI",  "TATA",  "TESLA",  "TOYOTA",  "VOLKSWAGEN", "VOLVO"];
  listOfType = ["Petrol", "Hybrid", "Diesel", "Electric", "CNG"];
  listOfColor = ["Amber",  "Aqua",  "Beige",  "Black",  "Blue",  "Bronze",  "Brown",  "Burgundy",  "Charcoal",  "Cobalt",  "Copper",  "Coral",  "Cream",  "Crimson",  "Cyan",  "Emerald",  "Forest Green",  "Fuchsia",  "Gold",  "Gray",  "Green",  "Indigo",  "Ivory",  "Lavender",  "Lemon",  "Lime",  "Magenta",  "Maroon",  "Mint",  "Navy",  "Olive",  "Orange",  "Peach",  "Pearl",  "Pink",  "Platinum",  "Purple",  "Red",  "Rose Gold",  "Rust",  "Saffron",  "Sand",  "Silver",  "Sky Blue",  "Slate",  "Steel Blue",  "Tan",  "Teal",  "Turquoise",  "Violet",  "White",  "Yellow"];
  listOfTransmission = ["Automated Manual Transmission (AMT)",  "Automatic",  "Continuously Variable Transmission (CVT)",  "Dual-Clutch Transmission (DCT)",  "Manual",  "Semi-Automatic"];


  constructor(private adminService: AdminService,
              private activatedRoute: ActivatedRoute,
              private fb: FormBuilder,
              private message: NzMessageService,
              private router: Router) {}

  ngOnInit(){
    this.updateForm = this.fb.group({
      name: [null, Validators.required],
      brand: [null, Validators.required],
      type: [null, Validators.required],
      color: [null, Validators.required],
      transmission: [null, Validators.required],
      price: [null, Validators.required],
      description: [null, Validators.required],
      year: [null, Validators.required],
    });
    this.getCarById();
  }

  getCarById(){
    this.isSpinning = true;
    this.adminService.getCarById(this.carId).subscribe((res) => {
      //console.log(res);
      this.isSpinning = false;
      const carDto= res;
      this.existingImage = 'data:image/jpeg;base64,' + res.returnedImage;
      carDto.year = new Date(carDto.year);
      console.log(carDto);
      console.log(this.existingImage);
      this.updateForm.patchValue(carDto);
    });
  }

  updateCar(){
    console.log(this.updateForm.value);
    this.isSpinning =true;
    const formData: FormData = new FormData();

    if (this.imgChanged && this.selectedFile){
      formData.append('image', this.selectedFile);
    }
    this.appendFormValue(formData,'brand' );
    this.appendFormValue(formData,'name' );
    this.appendFormValue(formData,'type' );
    this.appendFormValue(formData,'color' );
    this.appendFormValue(formData,'year' );
    this.appendFormValue(formData,'transmission' );
    this.appendFormValue(formData,'description' );
    this.appendFormValue(formData,'price' );

    console.log(formData);

    this.adminService.updateCar(this.carId, formData).subscribe(
      (res)=>{
        this.isSpinning = false;
        this.message.success("Car updated successfully", {nzDuration:5000});
        this.router.navigateByUrl("/admin/dashboard");
        console.log(res);
      },
      (error)=>{
        this.isSpinning = false;
        this.message.error("Error while updating car", {nzDuration:5000});
      }
    );
  }

  onFileSelected(event: any){
    const file = event.target.files[0];
    if (file) {
      this.selectedFile = file;
      this.imgChanged = true;
      this.existingImage = null;
      this.previewImage();
    }

  }

  previewImage(){
    const reader = new FileReader();
    reader.onload = () => {
      this.imagePreview = reader.result;
    };
    if (this.selectedFile) {
      reader.readAsDataURL(this.selectedFile);
    }
  }

  private appendFormValue(formData: FormData, controlName: string): void {
    const controlValue = this.updateForm.get(controlName)?.value;
    if (controlValue !== null && controlValue !== undefined) {
      formData.append(controlName, controlValue);
    }
  }

}
