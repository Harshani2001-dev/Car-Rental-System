import {Component, OnInit} from '@angular/core';
import {AdminService} from "../../services/admin.service";
import {NzMessageService} from "ng-zorro-antd/message";
import {Router} from "@angular/router";

interface Car {
  id: number;
  brand: string;
  color: string;
  name: string;
  type: string;
  transmission: string;
  description: string;
  price: number;
  year: Date;
  image: Uint8Array;
  returnedImage: string;
  processedImg?: string;
}

@Component({
  selector: 'app-admin-dashboard',
  templateUrl: './admin-dashboard.component.html',
  styleUrl: './admin-dashboard.component.scss'
})
export class AdminDashboardComponent implements OnInit{

  cars: Car[] = [];

  constructor(private adminService: AdminService,
              private message:NzMessageService,
              private router:Router){}

  ngOnInit(){
    this.getAllCars();
  }

  getAllCars(){
    this.adminService.getAllCars().subscribe((res: Car[])=>{
      console.log(res);
      res.forEach(element => {
        element.processedImg = 'data:image/jpeg;base64,' + element.returnedImage;
        this.cars.push(element);
      });
    });
  }

  deleteCar(id: number) {
    this.adminService.deleteCar(id).subscribe({
      next: (res) => {
        this.cars = this.cars.filter(car => car.id !== id);
        this.message.success('Car deleted successfully', {
          nzDuration: 5000,
        });
      },
      error: (err) => {
        this.message.error('Error while deleting car', { nzDuration: 5000 });
        console.error('Error while deleting car:', err);
      },
    });
  }

}
