import {Component, OnInit} from '@angular/core';
import {CustomerService} from "../../service/customer.service";
import {ActivatedRoute, Router} from "@angular/router";
import {FormBuilder, FormGroup, Validators} from "@angular/forms";
import {StorageService} from "../../../../auth/services/storage/storage.service";
import {NzMessageService} from "ng-zorro-antd/message";

@Component({
  selector: 'app-book-car',
  templateUrl: './book-car.component.html',
  styleUrl: './book-car.component.scss'
})
export class BookCarComponent implements OnInit{

  carId: number;
  car:any;
  processedImage: any;
  validateForm!: FormGroup;
  isSpinning = false;
  dateFormat: string = "dd-MM-yyyy";

  constructor(private service: CustomerService,
              private activatedRoute: ActivatedRoute,
              private fb:FormBuilder,
              private message:NzMessageService,
              private router: Router){
    this.carId = this.activatedRoute.snapshot.params["id"];
  }

  ngOnInit(){
    this.validateForm = this.fb.group({
      toDate: [null, Validators.required],
      fromDate: [null, Validators.required],
    })
    this.getCarById();
  }

  getCarById() {
    this.service.getCarById(this.carId).subscribe({
      next: (res) => {
        console.log(res);
        this.processedImage = 'data:image/jpeg;base64,' + res.returnedImage;
        this.car = res;
      },
      error: (err) => {
        console.error("Error fetching car details:", err);
      }
    });
  }

  bookACar(data: any){
    console.log(data);
    this.isSpinning = true;
    let bookACarDto = {
      toDate: data.toDate,
      fromDate: data.fromDate,
      userId: StorageService.getUserId(),
      carId: this.carId
    };
    this.service.bookACar(bookACarDto).subscribe({
      next: (res) => {
        console.log(res);
        this.message.success("Booking request submitted successfully", { nzDuration: 5000 });
        this.router.navigateByUrl("/customer/dashboard");
      },
      error: (error) => {
        this.isSpinning = false;
        this.message.error("Something went wrong", { nzDuration: 5000 });
      }
    });
  }

}
