import {Component, OnInit} from '@angular/core';
import {CustomerService} from "../../service/customer.service";

interface Car {
  id: number;
  brand: string;
  color: string;
  name: string;
  type: string;
  transmission: string;
  description: string;
  price: number;
  year: Date;
  image: Uint8Array;
  returnedImage: string;
  processedImg?: string;
}

@Component({
  selector: 'app-customer-dashboard',
  templateUrl: './customer-dashboard.component.html',
  styleUrl: './customer-dashboard.component.scss'
})
export class CustomerDashboardComponent implements OnInit{

  cars: Car[] = [];

  constructor(private service: CustomerService){}

  ngOnInit(){
    this.getAllCars();
  }

  getAllCars(){
    this.service.getAllCars().subscribe((res: Car[])=>{
      console.log(res);
      res.forEach(element => {
        element.processedImg = 'data:image/jpeg;base64,' + element.returnedImage;
        this.cars.push(element);
      });
    });
  }

}
