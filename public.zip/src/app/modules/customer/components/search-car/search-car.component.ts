import { Component } from '@angular/core';
import {FormBuilder, FormGroup} from "@angular/forms";
import {CustomerService} from "../../service/customer.service";

interface Car {
  id: number;
  brand: string;
  color: string;
  name: string;
  type: string;
  transmission: string;
  description: string;
  price: number;
  year: Date;
  image: Uint8Array;
  returnedImage: string;
  processedImg?: string;
}

@Component({
  selector: 'app-search-car',
  templateUrl: './search-car.component.html',
  styleUrl: './search-car.component.scss'
})
export class SearchCarComponent {

  searchCarForm!: FormGroup;
  isSpinning: boolean = false;
  cars: Car[] = [];
  noCarsFound: boolean = false;

  listOfOption: Array<{ label: string, value: string }> = [];

  listOfBrands = ["ACURA", "AUDI", "BENTLEY",  "BMW",  "BUGATTI",  "BUICK",  "CADILLAC",  "CHERY",  "CHRYSLER",  "CITROEN",  "DODGE",  "FERRARI",  "FORD",  "GMC",  "HONDA",  "HYUNDAI",  "INFINITI",  "JAGUAR",  "JEEP",  "KIA",  "LAMBORGHINI",  "LAND ROVER",  "LEXUS",  "LINCOLN",  "LOTUS",  "MAHINDRA",  "MASERATI",  "MAZDA",  "McLAREN",  "MERCEDES-BENZ",  "MINI",  "MITSUBISHI",  "NISSAN",  "PAGANI",  "PORSCHE",  "RENAULT",  "ROLLS-ROYCE",  "ROVER",  "SUBARU",  "SUZUKI",  "TATA",  "TESLA",  "TOYOTA",  "VOLKSWAGEN", "VOLVO"];
  listOfType = ["Petrol", "Hybrid", "Diesel", "Electric", "CNG"];
  listOfColor = ["Amber",  "Aqua",  "Beige",  "Black",  "Blue",  "Bronze",  "Brown",  "Burgundy",  "Charcoal",  "Cobalt",  "Copper",  "Coral",  "Cream",  "Crimson",  "Cyan",  "Emerald",  "Forest Green",  "Fuchsia",  "Gold",  "Gray",  "Green",  "Indigo",  "Ivory",  "Lavender",  "Lemon",  "Lime",  "Magenta",  "Maroon",  "Mint",  "Navy",  "Olive",  "Orange",  "Peach",  "Pearl",  "Pink",  "Platinum",  "Purple",  "Red",  "Rose Gold",  "Rust",  "Saffron",  "Sand",  "Silver",  "Sky Blue",  "Slate",  "Steel Blue",  "Tan",  "Teal",  "Turquoise",  "Violet",  "White",  "Yellow"];
  listOfTransmission = ["Automated Manual Transmission (AMT)",  "Automatic",  "Continuously Variable Transmission (CVT)",  "Dual-Clutch Transmission (DCT)",  "Manual",  "Semi-Automatic"];


  constructor(private fb: FormBuilder,
              private service: CustomerService){
    this.searchCarForm = this.fb.group({
      brand: [null],
      type: [null],
      transmission: [null],
      color: [null],
    });
  }

  ngOnInit(): void {
  }

  searchCar(){
    this.isSpinning = true;
    this.cars = [];
    this.noCarsFound = false;

    this.service.searchCar(this.searchCarForm.value).subscribe(
      (res: { carDtoList: Car[] }) => {
        if (res.carDtoList.length > 0) {
          res.carDtoList.forEach((element: Car) => {
            element.processedImg = 'data:image/jpeg;base64,' + element.returnedImage;
            this.cars.push(element);
          });
          this.noCarsFound = false;
        } else {
          this.noCarsFound = true; // No cars found
        }
        this.isSpinning = false;
      },
      (error) => {
        console.error('Search Error:', error);
        this.isSpinning = false;
        this.noCarsFound = true;
      }
    );
  }
}
