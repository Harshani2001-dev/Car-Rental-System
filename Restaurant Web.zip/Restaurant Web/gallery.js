document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();

        document.querySelector(this.getAttribute('href')).scrollIntoView({
            behavior: 'smooth'
        });
    });
});

document.addEventListener('DOMContentLoaded', function () {

    const restaurantImages = [
        'imgone.jfif',
        'imgtwo.jfif',
        'img3.jpg',
        'img4.jpg',
        'img5.jpg',
        'img6.jpg',
        'img7.jpg',
        'img8.jpg',
        'img9.jpg',
        'img10.jpg',
        'img11.jpg',
        'img12.jpg',
        'img13.jpg',
        'img14.jpg',
        'img15.jpg',
        'img16.jpg',
        'img17.jpg',
        'img18.jpg',
        'img19.jpeg',
        'img20.jpg',
        'img21.jpg',
        'img22.jpg',
        'img23.jpg',
    ];

    // Function to create and append gallery items
    function appendGalleryItem(container, category, imageSrc) {
        const galleryItem = document.createElement('div');
        galleryItem.classList.add('gallery-item', category);
        const img = document.createElement('img');
        img.src = imageSrc;
        img.alt = `${category} Image`;
        galleryItem.appendChild(img);

        // Add click event to open the full-size image
        galleryItem.addEventListener('click', function () {
            window.open(imageSrc, '_blank');
        });

        container.appendChild(galleryItem);
    }

    // Populate the restaurant category
    const galleryContainer = document.getElementById('galleryContainer');
    restaurantImages.forEach(imageSrc => {
        appendGalleryItem(galleryContainer, 'restaurant', imageSrc);
    
    });

});