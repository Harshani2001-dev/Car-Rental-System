document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();

        document.querySelector(this.getAttribute('href')).scrollIntoView({
            behavior: 'smooth'
        });
    });
});

document.addEventListener("DOMContentLoaded", function () {
    // Get all founder details elements
    var founderDetails = document.querySelectorAll(".founder-details");

    // Function to handle image click
    function toggleImageSize(image) {
        image.classList.toggle("zoomed");
    }

    // Attach click event listener to each founder details element
    founderDetails.forEach(function (founder) {
        var image = founder.querySelector("img");

        // Toggle image size on image click
        image.addEventListener("click", function () {
            toggleImageSize(image);
        });
    });
});

document.addEventListener("DOMContentLoaded", function () {
    // Get all chef details elements
    var chefDetails = document.querySelectorAll(".chef-details");

    // Function to handle image click
    function toggleImageSize(image) {
        image.classList.toggle("zoomed");
    }

    // Attach click event listener to each chef details element
    chefDetails.forEach(function (chef) {
        var image = chef.querySelector("img");

        // Toggle image size on image click
        image.addEventListener("click", function () {
            toggleImageSize(image);
        });
    });
});

