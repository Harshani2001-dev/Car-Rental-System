document.addEventListener("DOMContentLoaded", function () {
    // Smooth scrolling for navigation
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();

            document.querySelector(this.getAttribute('href')).scrollIntoView({
                behavior: 'smooth'
            });
        });
    });

    // Function to handle form submission
    function submitInquiry() {
        // Add logic to handle form submission (e.g., AJAX request)
        alert('Inquiry submitted! We will get back to you soon.');
    }

    // Attach form submission function to the form
    document.getElementById('inquiryForm').addEventListener('submit', function (e) {
        e.preventDefault();
        submitInquiry();
    });
});
