document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();

        document.querySelector(this.getAttribute('href')).scrollIntoView({
            behavior: 'smooth'
        });
    });
});

function checkAvailability() {
    // Placeholder logic, replace with your availability check logic
    const isAvailable = true; // Replace with your actual availability check

    if (isAvailable) {
        document.getElementById('availabilityMessage').innerText = 'Table is available for the selected date and time.';
    } else {
        document.getElementById('availabilityMessage').innerText = 'Sorry, the table is not available for the selected date and time. Please choose another time.';
    }
}

function confirmReservation() {
    // Placeholder logic, replace with your reservation confirmation logic
    const reservationConfirmed = true; // Replace with your actual confirmation logic

    if (reservationConfirmed) {
        alert('Reservation confirmed! You will receive a confirmation message.');
    } else {
        alert('Sorry, there was an error confirming your reservation. Please try again.');
    }
}

