document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();

        document.querySelector(this.getAttribute('href')).scrollIntoView({
            behavior: 'smooth'
        });
    });
});

// menu.js

// Function to open a modal with the full-size menu image
function viewMenuImage(category, imageSrc) {
    // Create a modal element
    const modal = document.createElement('div');
    modal.classList.add('modal');

    // Create an image element for the menu
    const menuImage = document.createElement('img');
    menuImage.src = imageSrc;
    menuImage.alt = `${category} Menu`;

    // Append the image to the modal
    modal.appendChild(menuImage);

    // Append the modal to the body
    document.body.appendChild(modal);

    // Add a click event to close the modal when clicking outside the image
    modal.addEventListener('click', function () {
        document.body.removeChild(modal);
    });
}
