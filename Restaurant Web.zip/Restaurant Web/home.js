document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();

        document.querySelector(this.getAttribute('href')).scrollIntoView({
            behavior: 'smooth'
        });
    });
});

// Display a welcome message with the current time
function displayWelcomeMessage() {
    const currentTime = new Date();
    const hours = currentTime.getHours();

    let greeting;

    if (hours < 12) {
        greeting = "Good morning";
    } else if (hours < 15) {
        greeting = "Good afternoon";
    } else {
        greeting = "Good evening";
    }

    const welcomeMessage = `${greeting}, welcome to Monsoon Restaurant!`;

    // Display the welcome message in the console and on the webpage
    console.log(welcomeMessage);
    alert(welcomeMessage);
}


